﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checkpoint01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ange Kommando");
            string str = Console.ReadLine();
            int size1 = int.Parse(str);
            string str2 = Console.ReadLine();
            int size2 = int.Parse(str2);

            int[] triangleRow = new int[size1];
            int[] triangleCol = new int[size2];


            for (int i = 0; i < triangleCol.Length; i++)
            {
                Console.WriteLine("*");
                for (int j = 0; j < triangleRow.Length; j++)
                {
                    Console.WriteLine("*");
                }
            }        




    

        }
    }
}



//Console.WriteLine("Ange en lista bestående av siffror separerade med streck");
//string str = Console.ReadLine();
//int size = Convert.ToInt32(str);

//int[] triangleSize = new int[size];
//for (int i = 0; i < triangleSize.Length; i++)
//{
//    Console.WriteLine("Ange storlek" + i + "; ");
//    str = Console.ReadLine();
//    int element = Convert.ToInt32(str);

//    triangleSize[i] = element;
//}
//int sum = 0;
//for (int i = 0; i < triangleSize.Length; i++) sum = sum + triangleSize[i];
//Console.WriteLine(sum / triangleSize.Length);
