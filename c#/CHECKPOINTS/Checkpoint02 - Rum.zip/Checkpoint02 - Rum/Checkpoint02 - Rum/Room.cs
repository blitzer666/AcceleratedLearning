﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Checkpoint02___Rum
{
    public class Room
    {
        public string Name { get; set; }
        public int M2 { get; set; }
        public string M2Number { get; set; }
    }
}
