﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.Logging;
using MyProj.Data;
using SpaceshipApp.Data;
using SpaceshipApp.Domain;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SpaceshipUI
{
    class Program
    {
        private static SpaceshipContext _context = new SpaceshipContext();

        static void Main(string[] args)
        {
            RecreateDatabase();
            AddSpaceship();
         
            GetAllSpaceships();
            DisplaySpaceships();

        }

        private static List<string> GetAllSpaceships()
        {
            using (var context = new SpaceshipContext())
            {
                return context.Spaceships.Select(s => $"{s.Name}").ToList();
            }

        }


        private static void DisplaySpaceships()
        {

            using (var context = new SpaceshipContext())
            {
                foreach (var spaceship in context.Spaceships)
                {
                    Console.WriteLine(spaceship.Name);
                    Console.WriteLine();
                    
                }
                Console.ReadLine();
            }
        }


        private static void RecreateDatabase()
        {
            using (var context = new SpaceshipContext())
            {
                context.Database.EnsureDeleted();
                context.Database.EnsureCreated();
            }
        }

        private static void AddSpaceship()
        {

            var spaceship = new Spaceship { Name = "USS Enterprise" };
            var spaceship2 = new Spaceship { Name = "Millennium Falcon" };
            var spaceship3 = new Spaceship { Name = "Cylon Raider" };

            using (var context = new SpaceshipContext())
            {
                context.Spaceships.AddRange(spaceship, spaceship2, spaceship3);
                context.SaveChanges();
            }

        }
        //private static void AddRavioliForSpaceship()
        //{

        //    var ravioli = new Ravioli {AntalBurkar = 2, Bästföre = "2018-04-19"};
        //    var spaceship2 = new Spaceship { Name = "Millennium Falcon" };
        //    var spaceship3 = new Spaceship { Name = "Cylon Raider" };

        //    using (var context = new SpaceshipContext())
        //    {
        //        context.Raviolis.AddRange(ravioli);
        //        context.SaveChanges();
        //    }

        //}
    }
}
