﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SpaceshipApp.Domain
{
    public class Ravioli
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int AntalBurkar { get; set; }
        public string Bästföre { get; set; }
        public string Packdatum { get; set; }
        public int SpaceshipId { get; set; }
    }
}
