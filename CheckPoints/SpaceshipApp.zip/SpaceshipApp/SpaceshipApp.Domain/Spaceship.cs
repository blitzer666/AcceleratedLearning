﻿namespace SpaceshipApp.Domain
{
    public class Spaceship
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Ravioli Ravioli { get; set; }
    }
}
