﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SpaceshipApp.Data.Migrations
{
    public partial class init3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "AntalBurkar",
                table: "Ravioli",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AntalBurkar",
                table: "Ravioli");
        }
    }
}
