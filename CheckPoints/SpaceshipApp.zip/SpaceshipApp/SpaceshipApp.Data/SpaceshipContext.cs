﻿using Microsoft.EntityFrameworkCore;
using SpaceshipApp.Domain;

namespace SpaceshipApp.Data
{
    public class SpaceshipContext : DbContext
    {

        public DbSet<Spaceship> Spaceships { get; set; }
        public DbSet<Ravioli>Raviolis { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {



            optionsBuilder.UseSqlServer("Server = (localdb)\\mssqllocaldb; Database = EfSpaceshipsCore; Trusted_Connection = True; ");
        }
    }
}
