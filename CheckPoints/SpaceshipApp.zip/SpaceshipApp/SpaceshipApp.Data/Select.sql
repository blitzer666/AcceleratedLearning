﻿Select *
From Spaceships