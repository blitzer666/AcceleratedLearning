﻿# DemoWithOneProject 2

Syfte: visa ett minimalt exempel med två tabeller, en en-till-många med Entity Framework