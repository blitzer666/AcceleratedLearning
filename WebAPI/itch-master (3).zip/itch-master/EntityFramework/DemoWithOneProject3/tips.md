﻿# Tips

## AddCategoriesAndFruits


Lägg till en frukt i en korg:

    b1.FruitInBaskets.Add(new FruitInBasket
    {
        Fruit = nypon
    });

## GetAllFruitsInBasket

Använd både *Include* och *ThenInclude* 