﻿use DemoWithOneProject3
select * from Baskets
select * from FruitCategories
select * from FruitInBasket
select * from Fruits