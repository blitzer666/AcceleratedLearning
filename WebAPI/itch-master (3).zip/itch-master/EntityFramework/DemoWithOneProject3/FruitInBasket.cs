﻿
namespace DemoWithOneProject3
{
    public class FruitInBasket
    {
        public int FruitId { get; set; }
        public Fruit Fruit { get; set; }

        public int BasketId { get; set; }
        public Basket Basket { get; set; }
    }
}
