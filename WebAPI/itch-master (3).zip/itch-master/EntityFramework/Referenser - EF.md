## Referenser 

Entity Framework Core: Getting Started
https://app.pluralsight.com/library/courses/entity-framework-core-getting-started/table-of-contents

Entity Framework Core - Microsoft guide
https://docs.microsoft.com/en-us/ef/core/

EF Core Tutorial
http://www.entityframeworktutorial.net/efcore/entity-framework-core.aspx


## Nugetpaket att installera

Entity Framework:

    Install-Package Microsoft.EntityFrameworkCore

F�r att f� tillg�ng till SQL-specifika funktioner

    Install-Package Microsoft.EntityFrameworkCore.SqlServer

F�r att kunna migrera med "Add-Migration"

    Install-Package Microsoft.EntityFrameworkCore.Tools






## EF Core Package Manager Console Tools (2017)

Installeras genom

    Install-Package Microsoft.EntityFrameworkCore.Tools

Hur du anv�nder
- Add-Migration
- Script-Migration
- Update-Database

https://docs.microsoft.com/en-us/ef/core/miscellaneous/cli/powershell

Rekommenderas av microsoft om du k�r Visual Studio

## EF Core .NET Command-line Tools (2017)

Ut�kar "dotnet"-kommandot. Motsvarar PMC Tools fast cross-plattform.

Toolsen �r en del av .NET Core SDK.

https://docs.microsoft.com/en-us/ef/core/miscellaneous/cli/dotnet