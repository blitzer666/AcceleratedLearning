﻿
delete from BattleEvent
delete from BattleLog
delete from Battles
delete from Quotes
delete from SamuraiBattle
delete from Samurais
delete from SecretIdentity