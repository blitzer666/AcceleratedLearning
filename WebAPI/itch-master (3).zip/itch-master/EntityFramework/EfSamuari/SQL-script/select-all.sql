﻿select * from Samurais
select * from SecretIdentity
select * from Quotes
select * from SamuraiBattles
select * from Battles
select * from BattleLog
select * from BattleEvent






