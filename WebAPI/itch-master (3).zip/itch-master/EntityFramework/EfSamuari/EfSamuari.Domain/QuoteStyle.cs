﻿namespace EfSamurai.Domain
{
    public enum QuoteStyle
    {
        Lame,
        Cheesy,
        Awesome
    }
}
