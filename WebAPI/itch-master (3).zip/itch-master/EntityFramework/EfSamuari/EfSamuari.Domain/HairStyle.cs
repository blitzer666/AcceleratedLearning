﻿namespace EfSamurai.Domain
{
    public enum HairStyle
    {
        Chonmage, Oicho, Western
    }
}
