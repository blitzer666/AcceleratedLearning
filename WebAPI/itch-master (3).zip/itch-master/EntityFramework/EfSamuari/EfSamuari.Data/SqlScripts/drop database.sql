﻿	use master
	alter database EfSamurai set single_user with rollback immediate
	drop database EfSamurai