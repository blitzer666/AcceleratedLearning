
# IDÉER

* Gör om inmatad till Morsespråk. Både tecken och välj om det ska pipa.

* Sträng => skriv i en ring, triangel, fyrkant. Kunna ställa in bas och tjocklek etc.

* Google maps => hitta alla ikea i världen. Vilka ike'or är närmst mig.

* Äventyrstextbaserat spel.

* Textbaserad fil med matrecept. Mata in vad du har för mat hemma. => förslag på recept + vad du behöver köpa. 

* Reseapplikation. Konvertera valuta och tidzoner.

* Översätt namn + tid till annan tidzon.

* Realtid hålla kolla på nån onlinetjänst som t.ex SL