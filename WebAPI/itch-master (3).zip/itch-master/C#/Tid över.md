# Tid �ver?

Om du gjort alla grund�vningar och extra�vningar i C#:

- Karma (hj�lp en kollega! fr�ga om n�n beh�ver hj�lp!)
- V�lj en �vning h�rifr�n: https://adriann.github.io/programming_problems.html
- Registrera dig p� CodeWars och g�r �vningar d�r https://www.codewars.com/?language=csharp
- Extra �vningar: https://github.com/happy-bits/itch/tree/master/C%23/%C3%96vningar/Extra
- Fr�ga l�raren efter �vningar eller diskutera eget projekt
