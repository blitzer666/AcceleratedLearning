﻿namespace M6_Classes
{
    public enum Sport
    {
        Tennis, Rugby, Soccer, Hurling, Squash
    }
}
