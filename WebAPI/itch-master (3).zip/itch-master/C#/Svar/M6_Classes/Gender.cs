﻿namespace M6_Classes
{
    public enum Gender
    {
        Female, Male, Other
    }
}
