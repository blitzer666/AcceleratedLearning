﻿namespace M12_Interfaces
{
    public interface IAggressive
    {
        int Bite();
        void ShowTeeth();
    }
}
