﻿

namespace M12_Interfaces
{
    public interface IFriendly
    {
        void Greet();
        void ThanksForDinner(string meal);
    }
}
