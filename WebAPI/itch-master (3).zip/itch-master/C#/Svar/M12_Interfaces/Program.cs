﻿namespace M12_Interfaces
{
    public class Program
    {

        public static void Main(string[] args)
        {
            // 12.1 Arrays, List and IEnumerable
           // new InterfaceLab1().Run();

            // 12.2 Custom interfaces
            new InterfaceLab2().Run();
        }
    }
}
