﻿using System;

namespace MethodsAndLists.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // new NumberListToNumberList().Run();
            // new NumberListToStringList().Run();
            // new NumberListToString().Run();
            // new StringListToBool().Run();
            // new StringListToNumber().Run();
            // new MultipleArguments().Run();
        }
    }
}
