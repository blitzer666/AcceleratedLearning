# Referenser i C#

## Dot Net Pearls
https://www.dotnetperls.com/

## Tutorial Point
https://www.tutorialspoint.com/csharp/

## Microsoft tutorial
https://docs.microsoft.com/en-us/dotnet/csharp/programming-guide/

## C# Yellow Book (gratis bok, 200s)
http://www.robmiles.com/c-yellow-book/

## Shortcuts
- https://docs.google.com/document/d/12yWSfpxIh3XXUfrG2xZB9eusDZHOBBFiggM-tddTzFM/ 
- https://www.youtube.com/watch?v=r4OunLmSMAU 
