spara ==> Properties / fält
- nuvarande våningsplan
- vikt (stanna om det är för tungt)
- ålder (service efter ett visst antal år / användning)
- riktning som hissen är påväg
- lägsta o högst våning

kommandon ==> Metoder
- åk upp! åk ner!
- stoppa hissen!
- åk till våning X!
- stäng/öppna dörr
- tillkalla tekniker
- återgå till entreplan