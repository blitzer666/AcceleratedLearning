﻿namespace ClassDemo
{
    class Program
    {
        static void Main()
        {
            new Version1.App().Run();
            //new Version2.App().Run();
            //new Version3.App().Run();
        }
    }
}
