# Referenser SQL

## W3Schools

Allt du beh�ver veta + det finns en try-it-yourself:

https://www.w3schools.com/sql/ 

## Tutorial point

Liknande som w3schools

https://www.tutorialspoint.com/sql/  

 
## Transaktioner

Mycket text men en del exempel l�ngst ner i SQL

https://docs.microsoft.com/en-us/sql/t-sql/language-elements/begin-transaction-transact-sql 	

Ett exempel p� transaktioner l�ngst ner i C#

https://msdn.microsoft.com/en-us/library/system.data.sqlclient.sqltransaction(v=vs.110).aspx 	