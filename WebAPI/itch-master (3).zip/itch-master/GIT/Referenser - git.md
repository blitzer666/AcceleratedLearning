# Referenser - git


## Getting started with Git using SourceTree

Mycket bra och kort tutorial (2016)

This video series teaches you Git version control without having to use the command line. As an interface, we use SourceTree from Atlassian and KDiff3 by Joachim Eibl.

https://www.youtube.com/watch?v=UD7PV8auGLg 

- Version control (7min)
- Working together (11min)
- Working on the same files (5min)
- Solving conflicts (6min)
- Ignoring files and folders (3min)
- Stashing (3min)


## Vad �r GIT och varf�r beh�vs det?

https://www.atlassian.com/git/tutorials/what-is-version-control

## Intro to Git and SourceTree

Kort men bra intro till Sourcetree och GIT (13 sidor)

2016

http://teleyah.com/cspro/EthiopiaSep2016/IntroGitSourceTree.pdf

## Git step by step

2013-2015

Har inte l�st igenom men verkar bra. Tre steg.

https://github.com/GSoft-SharePoint/Dynamite/wiki/Git-step-by-step:-Part-1
