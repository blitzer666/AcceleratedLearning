# 1 Commit�a frukter

## Starta ett repo lokalt

Skapa en tom mapp

Skapa ett lokalt repo mha *SourceTree*.�
V�lj att inte anv�nda github.com

## Commit

Skapa tv� textfiler:
- **Mina frukter.txt**
- **Om frukter.txt**

�och fyll filerna med inneh�ll

G�r *Stage All*. Skriv ett l�mpligt commitmeddelande och g�r Commit


## Commit II

L�gg till n�gra filer till. 

G�r *Stage All*. Skriv ett l�mpligt commitmeddelande och g�r Commit

## Ta bort en frukt

Nu ska vi g�ra en liten f�r�ndring i en av filerna.

Ta bort en frukt i **Mina frukter.txt**

G�r *Stage All*. Skriv ett l�mpligt commitmeddelande och g�r Commit

## Flera f�r�ndringar

G�r flera f�r�ndringar:

- Ta bort en frukt i **Mina frukter.txt** och l�gg till fem frukter i.
- Ta bort textfilen **Om frukt.txt**�
- L�gg till filen **Frukters n�ringsv�rden.txt** och skriv inneh�ll.
- L�gg in en bild **frukter.jpg**

Stage. Commit

## Extra

Ta reda p� vad *Stash* �r och anv�nd det tv� g�nger i ditt repo
