# 4 Consoleapp och ignorefilen

## Ny Console App

Skapa en ny Console App i Visual Studio. Bocka ur �Create new GIT repository�.

Skapa ett repo i SourceTree.

G�r ingen commit. Kolla p� **Unstaged files**.

Bygg programmet. Kolla p� **Unstage files** igen.

## Ignorefilen

Skapa en l�mplig ignore-fil till Console-appen.�

Vilka filer �r l�mpliga att ignore�a och varf�r?

Stage. Commit.

## Ny Console App II

Skapa en ny Console App i Visual Studio. Bocka i �Create new GIT repository�.

Vilka commits har skapats?

Hur ser ignore-filen ut?

