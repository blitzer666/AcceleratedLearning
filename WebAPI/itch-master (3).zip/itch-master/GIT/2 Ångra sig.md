# 2 �ngra sig

## �ngra i nuvarande commit

Ibland �ngrar en sig och vill �terg� till ett tidigare skede.

L�gg till en ny fil **B�tens historia.txt**�

Stage. Commit

G�r ett par avsiktliga fel i filen.

�ngra detta mha **Discard** 

G�r ett par avsiktliga fel i filen p� flera olika st�llen. 

�ngra detta mha **Reverse hunk**

## �ngra f�reg�ende commit

G�r ett par avsiktliga fel i **B�tens historia.txt**

Stage. Commit

�ngra det senaste mha *Reverse commit*

## Extra

1. Ta reda p� vad **Tag** �r och anv�nd det tv� g�nger i ditt repo
