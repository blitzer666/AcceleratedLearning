# Referenser - WebApi


## Webapi	

http://www.tutorialsteacher.com/webapi/what-is-web-api 	

Bra steg f�r steg guide till WebAPi'er. Bra bilder. Avskalat.

https://docs.microsoft.com/en-us/aspnet/web-api/

Index f�r allt som r�r WebApi av Microsoft

https://docs.microsoft.com/en-us/aspnet/web-api/overview/getting-started-with-aspnet-web-api/tutorial-your-first-web-api 

Bra exempel. Tv� GET-metoder mot h�rdkodad produktlista.

https://docs.microsoft.com/en-us/aspnet/web-api/overview/web-api-routing-and-actions/attribute-routing-in-web-api-2 	

Routing

https://docs.microsoft.com/en-us/aspnet/web-api/overview/web-api-routing-and-actions/create-a-rest-api-with-attribute-routing 	

Create a REST api. Bra exempel med b�cker. Men handlar om EF


## HTML

https://www.w3schools.com/html/ 	

Bra HTML-grunder. 

https://www.tutorialspoint.com/html/ 	

Liknar w3schools

https://www.w3schools.com/css/ 	

CSS-grunder. Bra. Kan livekoda i browsern.

## Javascript

https://www.w3schools.com/js/ 	

JS-grunder

https://javascript.info/ 	

Lite mer modern javascript

## Bootstrap


https://getbootstrap.com/ 	

Bootstrap - officiell sida