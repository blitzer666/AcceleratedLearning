﻿

namespace NewsApp.Models
{
    public class News
    {
        public int Id { get; set; }
        public string Header { get; set; }
    }
}
