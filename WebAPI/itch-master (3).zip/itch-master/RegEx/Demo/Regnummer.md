Success!

    ABC 123
    ABC123
    ZZZ 444
    ZZZ444
    ABC      123
    ZZZ   444

Fail!

     ABC 123
    ABC 12
    BC 123
    AB3 123
    ABC 1A3
    ABC-123
    AABC 123
    ABC 123 X

Svar:

    ^[A-Z]{3} *[0-9]{3}$