# Projekt � F�rsta dagen

# Intro

Vi b�rjar utbildningen med ett miniprojekt i grupp! 

# Genomf�r

G� ihop i grupper med 3-4 i varje grupp. Ta fram en website med f�ljande inneh�ll:

* Gruppens namn
* Presentation av alla gruppmedlemmar:
    * Namn
    * Vem �r du?
    * Ett udda intresse (l�sa korsord, spela cricket, rita enh�rningar)
    * G�rna bild
    
* Tre bra saker med f�rstudierna 

* Tre id�er som skulle f�rb�ttra f�rstudiematerialet 

Anv�nd HTML, CSS, Javascript. 

Det �r helt ok att g� loss med animationer, bilder, ljud, extra-allt, eldar, blinkande texter och hoppande katter.

# Gruppindelning

3 4 4 4

# Deadline

Skapa en zip-fil av ditt projekt och ladda upp h�r i Canvas senast **kl 16.00** 

Tips: skicka zip-filen f�rst till en kompis och verifiera att sajten funkar p� hans/hennes dator ocks�. (d� undviker du att bilder och script �r fell�nkade)

# Redovisning

Redovisning av grupparbetena sker kl 16.10 � 16.50. Sedan rundar vi av.

10 minuter per grupp.

Resurser

- https://www.w3schools.com/
- https://www.tutorialspoint.com/


