
// console.log + fel

console.log("hej")
console.Log("hej") // ger felmeddelande

// sätt och skriv ut varibel

let name="Lisa"
console.log("Hej " +name)

// summera två tal. fast strängar. parseInt

let x = 2;
let y = "3"
console.log(x+y)

let x = 2;
let y = parseInt("3")
console.log(x+y)

 
// snefnutt

let name="Kalle"

let s = "Ditt " + name + " namn är " + name
let s = `Ditt ${name} namn är ${name}`

// typeof 

let a = 1
let b = "2"
let c = true
let d = function(){alert('hej!')}
let e = [4,5,6]
let f = {firstName:"Lisa"}

a = "KALLE"

console.log(typeof a)
console.log(typeof b)
console.log(typeof c)
console.log(typeof d)
console.log(typeof e)
console.log(typeof f)
