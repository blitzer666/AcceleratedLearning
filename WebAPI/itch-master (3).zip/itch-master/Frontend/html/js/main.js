﻿alert("Välkommen till min sida");

document.getElementById("minKnapp").addEventListener("click", function () {
    document.getElementById("minRubrik").innerHTML = "Bla bla bla";
});