# box-state2.html - Ändra bakgrundsfärg

När knappen trycks ner så byt färg på rutan utifrån en palett av färger:

- Rött
- Grönt
- Blått


![](img/box2.png)
