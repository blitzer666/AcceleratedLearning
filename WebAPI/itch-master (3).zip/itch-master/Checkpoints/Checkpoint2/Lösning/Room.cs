﻿
namespace Checkpoint02.OscarOlsson.Level2
{
    public class Room
    {
        public string Name { get; set; }
        public int Size { get; set; }
    }
}
