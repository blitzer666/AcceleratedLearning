
# Checkpoint 02 - omprov

## Tid

2h

## Intro

Anv�ndaren matar in ett antal m�bler. M�blerna separareras med **kolon**

Varje m�bel anges i f�ljande format d�r namnet och priset �r separerat med **kommatecken**.

    NamnP�M�bel,Pris

T.ex

    Ange m�bler: 

    F�t�lj,1584:Billy bokhylla,299:Kallax hyllserie,899:Klippan-soffan,1795

D� ska programmet svara med vilken produkt som �r billigast, p� detta s�tt:

    Den billigaste produkten �r 'Billy bokhylla' och den kostar 299kr

(Du kan f�ruts�tta att det bara �r en m�bel som �r billigast)

Ett krav �r att du skapar en klass **Furniture** och att du skapar en **lista av Furniture** utifr�n de m�bler som anv�ndaren angett.

Du beh�ver inte bry dig om validering (du kan allts� f�ruts�tta att anv�ndaren skriver in m�blerna p� r�tt s�tt)