
# Checkpoint02 - Rum

## Intro

L�mna bara in en version. Du kan b�rja direkt p� niv� 2 om du vill.

## Tid 

2h

## Niv� 1

Anv�ndaren matar in rumsnamn tillsammans med storlek p� rummet. Storleken anges med en siffra samt texten "m2". Se nedan.

Skriv ut rummen och skriv �ven ut vilket rum som �r st�rst samt dess storlek.

L�s uppgiften genom att skapa en klass **Room** som du anv�nder i programmet (krav)

![](checkpoint02_2.png)


## Niv� 2

Anv�ndaren skriver nu rum i detta format:

    Rumsnamn Kvadratmeter LjusetP�EllerEj

T.ex

    Salong 15m2 On

Ljuset i ett rum �r antingen p� eller av: **On** eller **Off**.

Validera anv�ndarens input. Ge meddelande om anv�ndaren matar in p� fel format. Upprepa i all evighet.

N�r anv�ndaren matar in r�tt input s� skriv ut:
- Vilka rum som �r t�nda (om n�got) 
- Vilket rum som �r st�rst 
- Hur m�nga rum som har angivits

Se nedan f�r hur datan ska presenteras.

![](checkpoint02_3.png)
