# Tips inf�r checkpoint02

G� igenom projektet med "TV-tabl�n":

- https://github.com/happy-bits/itch/blob/master/C%23/Svar/M11_Linq/DemoLinq/Demo1.cs

�va p�:

- Skapa listor av egna objekt utifr�n en text (t.ex skapa en lista av 'Show')
- Jobba med listor (kunna l�gga till element, r�kna antalet element...etc)