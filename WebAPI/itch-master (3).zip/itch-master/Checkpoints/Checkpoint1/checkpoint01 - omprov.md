
# Checkpoint01 - Omprov

## Tid

1.5h

## Uppgift

Anv�ndaren matar in en siffra av tal (med mellanslag emellan), t.ex:

    Ange kommando: 5 3 11

D� ska programmet skriva ut kvadrater efter varandra med storleken 5, 3 och 11:

    OOOOOO
    OOOOOO
    OOOOOO
    OOOOOO
    OOOOOO

    OOO
    OOO
    OOO

    OOOOOOOOOOO
    OOOOOOOOOOO
    OOOOOOOOOOO
    OOOOOOOOOOO
    OOOOOOOOOOO
    OOOOOOOOOOO
    OOOOOOOOOOO
    OOOOOOOOOOO
    OOOOOOOOOOO
    OOOOOOOOOOO
    OOOOOOOOOOO

Fyrkanterna ska byggas upp av **O**'n. Det ska vara en tom rad mellan kvadraterna
