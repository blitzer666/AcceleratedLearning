
# Checkpoint 01 - Trianglar

## Tid

1.5h

## Intro

Skapa en console-app och l�s antingen Niv� 1 eller Niv� 2.

L�mna bara in en version av ditt program. 

## Inl�mningsinstruktioner

N�r du �r klar, skapa en **zip** av din l�sning.

Ta bort mapparna **.vs**, **bin** och **obj**.


## Niv� 1

Anv�ndaren matar in en lista av siffror separerade med streck. Rita ut trianglar mha stj�rnor. Trianglarn ska ha samma bas som h�jd. Trianglarna ska ritas upp under varandra.

I exemplet nedan s� ritas en triangel med storlek 5 upp, sedan en triangel med storlek 3 och sist en med storlek 7:

![](checkpoint01_2.png)

## Niv� 2

Anv�ndaren ska kunna skapa trianglar av tv� sorter:

- Triangel A har en spets i toppen
- Triangel B har en spets i botten

Exempel:

- Triangeln A2 har en spets i toppen och storleken 2.
- Triangeln B4 har en spets i botten och storleken 4.

Exempelk�rning:

![](checkpoint01_3.png)

