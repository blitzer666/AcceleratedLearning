# Tips inf�r checkpoint01

�va p�:

    Console.ReadLine
    Console.WriteLine

    Kunna skapa en lista fr�n en str�ng mha "Split"

    Parse'a str�ngar och tecken (int.Parse, char.Parse) 

    Loopa mha "for"

    L�sa problem med en "for"-loop i en annan "for"-loop. T.ex:

        for (int a = 1; a <= 2; a++)
        {
            for (int b = 1; b <= 3; b++)
            {
                Console.WriteLine(a + " " + b);
            }
        }

