
# Leveranser

	Sofia skickar gruppens databasmodell till Peter
	Peter skickar gruppens databasmodell till Ken
	Ken skickar gruppens databasmodell till Felicia
	Felicia skickar gruppens databasmodell till Sofia


# Affär

Kunder, Levarantörer, Varor, Locations, Anställda

	Sofia
	Johan
	Boris
	Astrid

# Eventföretag

Biljetter, Konserter, Genre, Teater

	Peter
	Ramy
	Anastasia

# Disneyland

Bokning, Hotellbokning, Attraktioner, Länder

	Kensiwat
	Rezan
	Isabelle
	Jesper

# Teater

Bokning, Kunder, Biljetter, Inventarier, Sittplatser

	Felicia
	Christoffer
	Christian